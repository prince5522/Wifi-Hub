const CACHE='wifi-hub-foundation-v1';
const SHELL=['./','./index.html','./manifest.json','./css/style.css','./js/app.js','./assets/icon.svg','./assets/wifi-bg.svg'];
self.addEventListener('install',e=>e.waitUntil(caches.open(CACHE).then(c=>c.addAll(SHELL)).then(()=>self.skipWaiting()).catch(()=>{})));
self.addEventListener('activate',e=>e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim())));
self.addEventListener('fetch',e=>{
 if(e.request.method!=='GET') return;
 e.respondWith(caches.match(e.request).then(c=>c||fetch(e.request)).catch(()=>caches.match('./index.html')));
});